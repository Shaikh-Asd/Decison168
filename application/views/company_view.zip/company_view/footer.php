<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-7">
                © Copyright 2013 - <span id="copyright"> <script> document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script></span>  |   <a href="http://decision168.com" target="_blank"> DECISION 168, Inc</a>  |   <a href="https://www.decision168.com/?page_id=841" target="_blank"> Cookies Policy</a>  |   <a href="https://www.decision168.com/privacy-policy/" target="_blank"> Privacy Policy</a>  |   <a href="https://www.decision168.com/terms-conditions/" target="_blank"> Terms &amp; Conditions</a>
            </div>
            <div class="col-sm-5">
                <div class="text-sm-end d-sm-block">
                    All Rights Reserved   |   Powered by <a href="https://www.z2squared.com/" target="_blank">z2 Squared</a>
                </div>
            </div>
        </div>
    </div>
</footer> 
