
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/libs/toastr/build/toastr.min.css">
<!-- Sweet Alert-->
<link href="<?php echo base_url();?>assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
        <!-- Bootstrap Css -->
<link href="<?php echo base_url();?>assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo base_url();?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo base_url();?>assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
<!--<link href="https://fonts.googleapis.com/css2?family=Sacramento&display=swap" rel="stylesheet">-->
<!--Start Meta Clear Browser Cache -->
    <meta http-equiv="cache-control" content="no-cache"> 
    <meta http-equiv="Pragma" content="no-cache"> 
    <meta http-equiv="Expires" content="-1"> 
    <!--End Meta Clear Browser Cache -->